from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from first_app.models import newtable
from . import forms
from django.views.decorators.csrf import csrf_exempt
import json


def index(request):
    return render(request,'firstapp/index.html')

def help(request):
    dynamic_Statment = {'check':'this is help.html'}
    return render(request,'firstapp/help.html',context=dynamic_Statment)

def login(request):
    form = forms.LoginForm()
    if request.method == "POST":
        form = forms.LoginForm(request.POST)
        if form.is_valid():
            print("Validation success")
            print("User Name"+form.cleaned_data['username'])
            print("Password"+form.cleaned_data['password'])
            return dashboard(request)

    return render(request,'firstapp/login.html',{'form':form})

def dashboard(request):
    dynamic_Statment = {'check':'this is help.html'}
    return render(request,'firstapp/dashboard.html',context=dynamic_Statment)

def ranking(request):
    dynamic_Statment = {'check':'this is help.html'}
    return render(request,'firstapp/ranking.html',context=dynamic_Statment)

def interview_invitation(request):
    dynamic_Statment = {'check':'this is help.html'}
    return render(request,'firstapp/interview_invite.html',context=dynamic_Statment)

def job_management(request):
    dynamic_Statment = {'check':'this is help.html'}
    return render(request,'firstapp/job_management.html',context=dynamic_Statment)
def Question_bank(request):
    dynamic_Statment = {'check':'this is help.html'}
    return render(request,'firstapp/Question_bank.html',context=dynamic_Statment)


def form_view(request):
        form = forms.LoginForm()
        return render(request,'firstapp/backendform.html',{'form':form})



@csrf_exempt
def webhook(request):
    # build a request object
    req = json.loads(request.body)
    # get action from json
    action = req.get('queryResult').get('action')
    print(req.get('queryResult'))
    # return a fulfillment message
    fulfillmentText = {'fulfillmentText': 'This is Django test response from webhook.'}
    # return response
    return JsonResponse(fulfillmentText, safe=False)


# Create your views here.
