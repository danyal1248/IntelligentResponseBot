from django import forms



class LoginForm(forms.Form):
    username = forms.CharField(widget=forms.EmailInput(
    attrs = {
    'class' : 'form-control',
    'id'    : 'email-login',
    'placeholder': 'User Name'

    }

    ))
    password = forms.CharField(widget=forms.PasswordInput(

    attrs = {
    'class' : 'form-control',
    'id'    : 'pwd-login',
    'placeholder': 'Password'

    }

    ))
